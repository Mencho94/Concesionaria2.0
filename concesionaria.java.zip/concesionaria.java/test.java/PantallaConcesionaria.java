import java.util.ArrayList;
import java.util.List;
import java.util.Comparator;
import entities.Vehiculo;
import entities.Moto;
import entities.Auto;

public class PantallaConcesionaria {
    public static void main(String[] args) {
        List<Vehiculo> list = new ArrayList();
        list.add(new Auto("Peugeot", "206", 4, 200000.00));
        list.add(new Moto("Honda", "Titan", 125, 60000.00));
        list.add(new Auto("Peugeot", "208", 5, 250000.00));
        list.add(new Moto("Yamaha", "YBR", 160, 80500.50));

        System.out.println("                     ***CONCESIONARIA***                    ");

        list.stream().forEach(System.out::println);
        System.out.println("************************************************************");

        double precioMaximo = list
                .stream()
                .max(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        System.out.print(" Vehiculo mas caro:");
        list
                .stream()
                .filter(p -> p.getPrecio() == precioMaximo)
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo()));

        double precioMinimo = list
                .stream()
                .min(Comparator.comparingDouble(Vehiculo::getPrecio))
                .get()
                .getPrecio();
        System.out.print(" Vehiculo mas barato:");
        list
                .stream()
                .filter(p -> p.getPrecio() == precioMinimo)
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo()));
        System.out.print(" Vehiculo que contiene en el modelo la letra 'Y':");
        list
                .stream()
                .filter(p -> p.getMarca().toLowerCase().startsWith("Y".toLowerCase()))
                .forEach(p -> System.out.println(p.getMarca() + " " + p.getModelo() + " "+ "$" + p.getPrecioEpecifico()));

        System.out.println("************************************************************");

        System.out.println("  Vehiculos ordenados por precio de mayor a menor:");
        list
                .stream()
                .sorted(Comparator.comparingDouble(Vehiculo::getPrecio).reversed())
                .forEach(o -> System.out.println(o.getMarca()+" "+o.getModelo()));

        System.out.println("************************************************************");

        System.out.println("  Vehiculo ordenados por orden natural(marca, modelo, precio):");
        list
                .stream()
                .sorted()
                .forEach(System.out::println);

    }
}
